import math
import torch
import torch.nn as nn
import torch.nn.functional as F


class BasicBlock(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size):
        super(BasicBlock, self).__init__()
        padding = int((kernel_size - 1) / 2)
        self.layers = nn.Sequential()
        self.layers.add_module('Conv',
                               nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=1, padding=padding,
                                         bias=False))
        self.layers.add_module('BatchNorm', nn.BatchNorm2d(out_planes))
        self.layers.add_module('ReLU', nn.ReLU(inplace=True))

    def forward(self, x):
        return self.layers(x)
        # feat = F.avg_pool2d(feat, feat.size(3)).view(-1, self.nChannels)


class EncBlock(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size):
        super(EncBlock, self).__init__()
        padding = int((kernel_size - 1) / 2)
        self.layers = nn.Sequential()
        self.layers.add_module('Conv',
                               nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=1, padding=padding,
                                         bias=False))
        self.layers.add_module('BatchNorm', nn.BatchNorm2d(out_planes))

    def forward(self, x):
        out = self.layers(x)
        return torch.cat([x, out], dim=1)


class DecBlock(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size):
        super(DecBlock, self).__init__()
        padding = int((kernel_size - 1) / 2)
        self.layers = nn.Sequential()
        self.layers.add_module('Conv',
                               nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=1, padding=padding,
                                         bias=False))

    def forward(self, x):
        out = self.layers(x)
        return out


class GlobalAveragePooling(nn.Module):
    def __init__(self):
        super(GlobalAveragePooling, self).__init__()

    def forward(self, feat):
        num_channels = feat.size(1)
        return F.avg_pool2d(feat, (feat.size(2), feat.size(3))).view(-1, num_channels)


class NetworkInNetwork(nn.Module):
    def __init__(self, _num_inchannels=3, _num_stages=3, _use_avg_on_conv3=True):
        super(NetworkInNetwork, self).__init__()

        num_inchannels = _num_inchannels
        num_stages = _num_stages
        use_avg_on_conv3 = _use_avg_on_conv3

        assert (num_stages >= 3)
        nChannels = 192
        nChannels2 = 160
        nChannels3 = 96

        blocks = [nn.Sequential() for _ in range(num_stages)]
        # 1st block -- start of encoder
        blocks[0].add_module('Block1_ConvB1', BasicBlock(num_inchannels, nChannels, 5))
        blocks[0].add_module('Block1_ConvB2', BasicBlock(nChannels, nChannels2, 1))
        blocks[0].add_module('Block1_ConvB3', BasicBlock(nChannels2, nChannels3, 1))
        blocks[0].add_module('Block1_MaxPool',
                             nn.MaxPool2d(kernel_size=3, stride=2, padding=1))  # reduce feature map to 1/2 size

        # 2nd block -- end of encoder
        blocks[1].add_module('Block2_ConvB1', BasicBlock(nChannels3, nChannels, 5))
        blocks[1].add_module('Block2_ConvB2', BasicBlock(nChannels, nChannels, 1))
        blocks[1].add_module('Block2_ConvB3', BasicBlock(nChannels, nChannels, 1))
        blocks[1].add_module('Block2_AvgPool',
                             nn.AvgPool2d(kernel_size=3, stride=2, padding=1))  # reduce feature map to 1/2 size
        blocks[1].add_module('Block2_Encode', EncBlock(nChannels, nChannels, 1))

        # 3rd block -- decoder
        blocks[2].add_module('Block3_ConvB1', BasicBlock(nChannels, nChannels, 3))
        blocks[2].add_module('Block3_ConvB2', BasicBlock(nChannels, nChannels, 1))
        blocks[2].add_module('Block3_ConvB3', BasicBlock(nChannels, nChannels, 1))

        # Additional Layer for decoder
        if num_stages > 3 and use_avg_on_conv3:
            blocks[2].add_module('Block3_AvgPool', nn.AvgPool2d(kernel_size=3, stride=2, padding=1))

        for s in range(3, num_stages):
            blocks[s].add_module('Block' + str(s + 1) + '_ConvB1', BasicBlock(nChannels, nChannels, 3))
            blocks[s].add_module('Block' + str(s + 1) + '_ConvB2', BasicBlock(nChannels, nChannels, 1))
            blocks[s].add_module('Block' + str(s + 1) + '_ConvB3', BasicBlock(nChannels, nChannels, 1))

        # global average pooling and classifier
        blocks.append(nn.Sequential())
        blocks[-1].add_module('GlobalAveragePooling', GlobalAveragePooling())

        self._feature_blocks = nn.ModuleList(blocks)
        self.image_decoder = ImageDecoder(in_channels=num_inchannels)
        # Record names of features for each layer
        self.all_feat_names = ['conv' + str(s + 1) for s in range(num_stages)] + ['classifier', ]
        assert (len(self.all_feat_names) == len(self._feature_blocks))

        self.weight_initialization()

    def _parse_out_keys_arg(self, out_feat_keys):

        # By default(when set to None) return the features of the last layer / module.
        out_feat_keys = [self.all_feat_names[-1]] if out_feat_keys is None else out_feat_keys

        if len(out_feat_keys) == 0:
            raise ValueError('Empty list of output feature keys.')
        for f, key in enumerate(out_feat_keys):
            if key not in self.all_feat_names:
                raise ValueError(
                    'Feature with name {0} does not exist. Existing features: {1}.'.format(key, self.all_feat_names))
            elif key in out_feat_keys[:f]:
                raise ValueError('Duplicate output feature key: {0}.'.format(key))

        # Find the highest output feature in `out_feat_keys
        max_out_feat = max([self.all_feat_names.index(key) for key in out_feat_keys])

        return out_feat_keys, max_out_feat

    def forward(self, x, out_feat_keys=None):
        out_feat_keys, max_out_feat = self._parse_out_keys_arg(out_feat_keys)
        out_feats = [None] * len(out_feat_keys)

        feat = x
        # encode
        for f in range(2):
            feat = self._feature_blocks[f](feat)
            key = self.all_feat_names[f]
            if key in out_feat_keys:
                out_feats[out_feat_keys.index(key)] = feat

        # reparameterize
        mu = feat[:, :192]
        logvar = feat[:, 192:]
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        feat = eps.mul(std * 0.001).add_(mu)

        # Decode Images
        img_mu, img_logvar = self.image_decoder(feat)

        # decode
        for f in range(2, max_out_feat + 1):
            feat = self._feature_blocks[f](feat)
            key = self.all_feat_names[f]
            if key in out_feat_keys:
                out_feats[out_feat_keys.index(key)] = feat

        t_out_feats = out_feats[0] if len(out_feats) == 1 else out_feats
        return t_out_feats, img_mu, img_logvar

    def weight_initialization(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                if m.weight.requires_grad:
                    n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                    m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, nn.BatchNorm2d):
                if m.weight.requires_grad:
                    m.weight.data.fill_(1)
                if m.bias.requires_grad:
                    m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                if m.bias.requires_grad:
                    m.bias.data.zero_()


class ImageDecoder(nn.Module):
    def __init__(self, in_channels):
        super(ImageDecoder, self).__init__()
        n_channel = 192
        n_channel2 = 160
        n_channel3 = 96
        blocks = [nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
                  BasicBlock(n_channel, n_channel, 1),
                  BasicBlock(n_channel, n_channel, 1),
                  BasicBlock(n_channel, n_channel3, 5),
                  nn.Upsample(scale_factor=2, mode='bilinear', align_corners=True),
                  BasicBlock(n_channel3, n_channel2, 1),
                  BasicBlock(n_channel2, n_channel, 1),
                  BasicBlock(n_channel, in_channels, 5),
                  DecBlock(in_channels, in_channels * 2, 1),
                  ]
        self.net = nn.Sequential(*blocks)
        self.weight_initialization()

    def forward(self, encode_feats):
        mu, log_var = torch.chunk(self.net(encode_feats), chunks=2, dim=1)
        return mu, log_var

    def weight_initialization(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                if m.weight.requires_grad:
                    n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                    m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, nn.BatchNorm2d):
                if m.weight.requires_grad:
                    m.weight.data.fill_(1)
                if m.bias.requires_grad:
                    m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                if m.bias.requires_grad:
                    m.bias.data.zero_()


class Regressor(nn.Module):
    def __init__(self, _num_stages=3, _use_avg_on_conv3=True, indim=384, num_classes=8, in_channels=3):
        super(Regressor, self).__init__()
        self.nin = NetworkInNetwork(_num_stages=_num_stages, _use_avg_on_conv3=_use_avg_on_conv3)
        self.t_fc_mu = nn.Linear(indim, num_classes)
        self.t_fc_logvar = nn.Linear(indim, num_classes)
        for m in self.modules():
            if isinstance(m, nn.Linear):
                m.bias.data.zero_()

    def forward(self, x1, x2, out_feat_keys=None):
        t_out_feat1, img_mu1, img_logvar1 = self.nin(x1, out_feat_keys)
        t_out_feat2, img_mu2, img_logvar2 = self.nin(x2, out_feat_keys)
        img_mu = torch.cat([img_mu1, img_mu2])
        img_logvar = torch.cat([img_logvar1, img_logvar2])
        if not out_feat_keys:
            t_out_feat = torch.cat((t_out_feat1, t_out_feat2), dim=1)
            t_mu = self.t_fc_mu(t_out_feat)
            t_logvar = self.t_fc_logvar(t_out_feat)
            return t_mu, t_logvar, img_mu, img_logvar, t_out_feat
        else:
            return x1, x2
