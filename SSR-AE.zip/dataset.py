from __future__ import print_function

import glob
import os
import os.path
import random
import sys
import warnings

import numpy as np
import torchvision.transforms as tf
from PIL import Image, PILLOW_VERSION
from torch.utils.data import Dataset
import scipy.io as scio
from torchvision.datasets import VisionDataset
from torchvision.datasets.mnist import read_image_file, read_label_file

if sys.version_info[0] == 2:
    import cPickle as pickle
else:
    import pickle

import torch
import torch.utils.data as data
from torchvision.datasets.utils import download_url, check_integrity, download_and_extract_archive

from PIL import ImageFile

ImageFile.LOAD_TRUNCATED_IMAGES = True


def find_coeffs(pa, pb):
    matrix = []
    for p1, p2 in zip(pa, pb):
        matrix.append([p1[0], p1[1], 1, 0, 0, 0, -p2[0] * p1[0], -p2[0] * p1[1]])
        matrix.append([0, 0, 0, p1[0], p1[1], 1, -p2[1] * p1[0], -p2[1] * p1[1]])

    A = np.matrix(matrix, dtype=np.float)
    B = np.array(pb).reshape(8)

    res = np.dot(np.linalg.inv(A.T * A) * A.T, B)
    return np.array(res).reshape(8)


def projective_transform(img1, shift, scale, fillcolor, resample):
    width, height = img1.size
    center = (img1.size[0] * 0.5 + 0.5, img1.size[1] * 0.5 + 0.5)
    shift = [float(random.randint(-int(shift), int(shift))) for _ in range(8)]
    scale = random.uniform(scale[0], scale[1])
    rotation = random.randint(0, 3)

    pts = [((0 - center[0]) * scale + center[0], (0 - center[1]) * scale + center[1]),
           ((width - center[0]) * scale + center[0], (0 - center[1]) * scale + center[1]),
           ((width - center[0]) * scale + center[0], (height - center[1]) * scale + center[1]),
           ((0 - center[0]) * scale + center[0], (height - center[1]) * scale + center[1])]
    pts = [pts[(ii + rotation) % 4] for ii in range(4)]
    pts = [(pts[ii][0] + shift[2 * ii], pts[ii][1] + shift[2 * ii + 1]) for ii in range(4)]

    coeffs = find_coeffs(pts, [(0, 0), (width, 0), (width, height), (0, height)])

    kwargs = {"fillcolor": fillcolor} if PILLOW_VERSION[0] == '5' else {}
    img2 = img1.transform((width, height), Image.PERSPECTIVE, coeffs, resample, **kwargs)
    return img2, coeffs


class CIFAR10(data.Dataset):
    """`CIFAR10 <https://www.cs.toronto.edu/~kriz/cifar.html>`_ Dataset.

    Args:
        root (string): Root directory of dataset where directory
            ``cifar-10-batches-py`` exists or will be saved to if download is set to True.
        train (bool, optional): If True, creates dataset from training set, otherwise
            creates from test set.
        transform (callable, optional): A function/transform that  takes in an PIL image
            and returns a transformed version. E.g, ``transforms.RandomCrop``
        target_transform (callable, optional): A function/transform that takes in the
            target and transforms it.
        download (bool, optional): If true, downloads the dataset from the internet and
            puts it in root directory. If dataset is already downloaded, it is not
            downloaded again.

    """
    base_folder = 'cifar-10-batches-py'
    url = "https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz"
    filename = "cifar-10-python.tar.gz"
    tgz_md5 = 'c58f30108f718f92721af3b95e74349a'
    train_list = [
        ['data_batch_1', 'c99cafc152244af753f735de768cd75f'],
        ['data_batch_2', 'd4bba439e000b95fd0a9bffe97cbabec'],
        ['data_batch_3', '54ebc095f3ab1f0389bbae665268c751'],
        ['data_batch_4', '634d18415352ddfa80567beed471001a'],
        ['data_batch_5', '482c414d41f54cd18b22e5b47cb7c3cb'],
    ]

    test_list = [
        ['test_batch', '40351d587109b95175f43aff81a1287e'],
    ]

    def __init__(self, root, shift=6, scale=None, resample=False, fillcolor=0, train=True,
                 transform_pre=None, transform=None, target_transform=None, matrix_transform=None,
                 download=False, cifar_class=0):
        self.root = os.path.expanduser(root)
        self.transform_pre = transform_pre
        self.transform = transform
        self.target_transform = target_transform
        self.matrix_transform = matrix_transform
        self.train = train  # training set or test set

        if download:
            self.download()

        if not self._check_integrity():
            raise RuntimeError('Dataset not found or corrupted.' +
                               ' You can use download=True to download it')

        # now load the picked numpy arrays
        if self.train:
            self.train_data = []
            self.train_labels = []
            for fentry in self.train_list:
                f = fentry[0]
                file = os.path.join(self.root, self.base_folder, f)
                fo = open(file, 'rb')
                if sys.version_info[0] == 2:
                    entry = pickle.load(fo)
                else:
                    entry = pickle.load(fo, encoding='latin1')
                self.train_data.append(entry['data'])
                if 'labels' in entry:
                    self.train_labels += entry['labels']
                else:
                    self.train_labels += entry['fine_labels']
                fo.close()

            self.train_labels = np.array(self.train_labels)

            target_indices = np.argwhere(self.train_labels == cifar_class)

            self.train_data = np.concatenate(self.train_data)
            self.train_data = self.train_data.reshape((50000, 3, 32, 32))[target_indices]
            self.train_data = np.squeeze(self.train_data)
            self.train_data = self.train_data.transpose((0, 2, 3, 1))  # convert to HWC
        else:
            f = self.test_list[0][0]
            file = os.path.join(self.root, self.base_folder, f)
            fo = open(file, 'rb')
            if sys.version_info[0] == 2:
                entry = pickle.load(fo)
            else:
                entry = pickle.load(fo, encoding='latin1')
            self.test_data = entry['data']
            if 'labels' in entry:
                self.test_labels = entry['labels']
            else:
                self.test_labels = entry['fine_labels']
            fo.close()

            self.test_labels = np.array(self.test_labels)
            nor_indices = np.argwhere(self.test_labels == cifar_class)
            ano_indices = np.argwhere(self.test_labels != cifar_class)

            self.test_labels[nor_indices] = 0
            self.test_labels[ano_indices] = 1

            self.test_data = self.test_data.reshape((10000, 3, 32, 32))
            self.test_data = self.test_data.transpose((0, 2, 3, 1))  # convert to HWC

        # projective transformation
        if scale is not None:
            assert isinstance(scale, (tuple, list)) and len(scale) == 2, \
                "scale should be a list or tuple and it must be of length 2."
            for s in scale:
                if s <= 0:
                    raise ValueError("scale values should be positive")
        self.scale = scale

        self.shift = shift

        self.resample = resample
        self.fillcolor = fillcolor

    def __getitem__(self, index):
        if self.train:
            img1, target = self.train_data[index], self.train_labels[index]
        else:
            img1, target = self.test_data[index], self.test_labels[index]

        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        img1 = Image.fromarray(img1)
        if self.transform_pre is not None:
            img1 = self.transform_pre(img1)

        # projective transformation on image2        
        width, height = img1.size
        center = (img1.size[0] * 0.5 + 0.5, img1.size[1] * 0.5 + 0.5)
        shift = [float(random.randint(-int(self.shift), int(self.shift))) for ii in range(8)]
        scale = random.uniform(self.scale[0], self.scale[1])
        rotation = random.randint(0, 3)

        pts = [((0 - center[0]) * scale + center[0], (0 - center[1]) * scale + center[1]),
               ((width - center[0]) * scale + center[0], (0 - center[1]) * scale + center[1]),
               ((width - center[0]) * scale + center[0], (height - center[1]) * scale + center[1]),
               ((0 - center[0]) * scale + center[0], (height - center[1]) * scale + center[1])]
        pts = [pts[(ii + rotation) % 4] for ii in range(4)]
        pts = [(pts[ii][0] + shift[2 * ii], pts[ii][1] + shift[2 * ii + 1]) for ii in range(4)]

        coeffs = find_coeffs(pts, [(0, 0), (width, 0), (width, height), (0, height)])

        kwargs = {"fillcolor": self.fillcolor} if PILLOW_VERSION[0] == '5' else {}
        img2 = img1.transform((width, height), Image.PERSPECTIVE, coeffs, self.resample, **kwargs)

        if self.transform is not None:
            img1 = self.transform(img1)
            img2 = self.transform(img2)

        if self.target_transform is not None:
            target = self.target_transform(target)

        coeffs = torch.from_numpy(np.array(coeffs, np.float32, copy=False)).view(8, 1, 1)

        if self.matrix_transform is not None:
            coeffs = self.matrix_transform(coeffs)

        return img1, img2, coeffs, target

    def __len__(self):
        if self.train:
            return len(self.train_data)
        else:
            return len(self.test_data)

    def _check_integrity(self):
        root = self.root
        for fentry in (self.train_list + self.test_list):
            filename, md5 = fentry[0], fentry[1]
            fpath = os.path.join(root, self.base_folder, filename)
            if not check_integrity(fpath, md5):
                return False
        return True

    def download(self):
        import tarfile

        if self._check_integrity():
            print('Files already downloaded and verified')
            return

        root = self.root
        download_url(self.url, root, self.filename, self.tgz_md5)

        # extract file
        cwd = os.getcwd()
        tar = tarfile.open(os.path.join(root, self.filename), "r:gz")
        os.chdir(root)
        tar.extractall()
        tar.close()
        os.chdir(cwd)

    def __repr__(self):
        fmt_str = 'Dataset ' + self.__class__.__name__ + '\n'
        fmt_str += '    Number of datapoints: {}\n'.format(self.__len__())
        tmp = 'train' if self.train is True else 'test'
        fmt_str += '    Split: {}\n'.format(tmp)
        fmt_str += '    Root Location: {}\n'.format(self.root)
        tmp = '    Transforms (if any): '
        fmt_str += '{0}{1}\n'.format(tmp, self.transform.__repr__().replace('\n', '\n' + ' ' * len(tmp)))
        tmp = '    Target Transforms (if any): '
        fmt_str += '{0}{1}'.format(tmp, self.target_transform.__repr__().replace('\n', '\n' + ' ' * len(tmp)))
        return fmt_str


class MVTechTrainDataset(Dataset):
    def __init__(self, data_root, data_mode='part', shift=6, scale=None, resample=False, fillcolor=0,
                 transform_pre=None, transform=None, matrix_transform=None):

        self.shift = shift
        self.scale = scale
        self.resample = resample
        self.fillcolor = fillcolor
        self.transform_pre = transform_pre
        self.transform = transform
        self.matrix_transform = matrix_transform

        self.image_list = []
        if data_mode == 'all':
            print(f'Loading MVTechAD Training Images from {data_root} ...')
            for classpath in glob.glob(f'{data_root}/*'):
                self.image_list.extend(sorted(glob.glob(f'{classpath}/train/good/*.png')))
        else:
            print(f'Loading MVTechAD Training Images from {data_root}/train/good/ ...')
            self.image_list.extend(sorted(glob.glob(f'{data_root}/train/good/*.png')))

    def __len__(self):
        return len(self.image_list)

    def __getitem__(self, index):
        img1 = Image.open(self.image_list[index]).convert('RGB')
        # preprocess transform on image1
        img1 = self.transform_pre(img1) if self.transform_pre else img1
        # projective transformation on image1 to get image2
        width, height = img1.size
        # calculate image center point
        center = (img1.size[0] * 0.5 + 0.5, img1.size[1] * 0.5 + 0.5)
        # sampling shifting coefficient
        shift = [float(random.randint(-int(self.shift), int(self.shift))) for _ in range(8)]
        # sampling scale ratio
        scale = random.uniform(self.scale[0], self.scale[1])
        # sampling rotation degree
        rotation = random.randint(0, 3)

        # projective transform
        pts = [((0 - center[0]) * scale + center[0], (0 - center[1]) * scale + center[1]),
               ((width - center[0]) * scale + center[0], (0 - center[1]) * scale + center[1]),
               ((width - center[0]) * scale + center[0], (height - center[1]) * scale + center[1]),
               ((0 - center[0]) * scale + center[0], (height - center[1]) * scale + center[1])]
        pts = [pts[(ii + rotation) % 4] for ii in range(4)]
        pts = [(pts[ii][0] + shift[2 * ii], pts[ii][1] + shift[2 * ii + 1]) for ii in range(4)]

        coeffs = find_coeffs(pts, [(0, 0), (width, 0), (width, height), (0, height)])

        kwargs = {"fillcolor": self.fillcolor} if PILLOW_VERSION[0] == '5' else {}
        img2 = img1.transform((width, height), Image.PERSPECTIVE, coeffs, self.resample, **kwargs)

        # post transform on the image: normalized and converted to tensor
        if self.transform:
            img1 = self.transform(img1)
            img2 = self.transform(img2)

        coeffs = torch.from_numpy(np.array(coeffs, np.float32, copy=False)).view(8, 1, 1)

        # normalize transform parameters
        coeffs = self.matrix_transform(coeffs) if self.matrix_transform else coeffs

        return img1, img2, coeffs


class MVTechTestDataset(Dataset):
    def __init__(self, data_root, data_mode='part', shift=6, scale=None, resample=False, fillcolor=0,
                 transform_pre=None, transform=None, matrix_transform=None):
        self.image_list = []
        self.labels = []

        self.shift = shift
        self.scale = scale
        self.resample = resample
        self.fillcolor = fillcolor
        self.transform_pre = transform_pre
        self.transform = transform
        self.matrix_transform = matrix_transform

        if data_mode == 'all':
            print(f'Loading MVTechAD Testing Images from {data_root} ...')
            for classpath in glob.glob(f'{data_root}/*'):
                for test_type_path in glob.glob(f'{classpath}/test/*'):
                    type_object_list = sorted(glob.glob(f'{test_type_path}/*.png'))
                    self.image_list.extend(type_object_list)
                    if 'good' in test_type_path:
                        self.labels.extend(len(type_object_list) * [0])
                    else:
                        self.labels.extend(len(type_object_list) * [1])
        else:
            print(f'Loading MVTechAD Testing Images from {data_root}/test ...')
            for test_type_path in glob.glob(f'{data_root}\\test\\*'):
                type_object_list = sorted(glob.glob(f'{test_type_path}\\*.png'))
                self.image_list.extend(type_object_list)
                if 'good' in test_type_path:
                    self.labels.extend(len(type_object_list) * [0])
                else:
                    self.labels.extend(len(type_object_list) * [1])

    def __len__(self):
        return len(self.image_list)

    def __getitem__(self, index):
        img1 = Image.open(self.image_list[index]).convert('RGB')
        # preprocess transform on image1
        img1 = self.transform_pre(img1) if self.transform_pre else img1
        # projective transformation on image1 to get image2
        width, height = img1.size
        # calculate image center point
        center = (img1.size[0] * 0.5 + 0.5, img1.size[1] * 0.5 + 0.5)
        # sampling shifting coefficient
        shift = [float(random.randint(-int(self.shift), int(self.shift))) for _ in range(8)]
        # sampling scale ratio
        scale = random.uniform(self.scale[0], self.scale[1])
        # sampling rotation degree
        rotation = random.randint(0, 3)

        # projective transform
        pts = [((0 - center[0]) * scale + center[0], (0 - center[1]) * scale + center[1]),
               ((width - center[0]) * scale + center[0], (0 - center[1]) * scale + center[1]),
               ((width - center[0]) * scale + center[0], (height - center[1]) * scale + center[1]),
               ((0 - center[0]) * scale + center[0], (height - center[1]) * scale + center[1])]
        pts = [pts[(ii + rotation) % 4] for ii in range(4)]
        pts = [(pts[ii][0] + shift[2 * ii], pts[ii][1] + shift[2 * ii + 1]) for ii in range(4)]

        coeffs = find_coeffs(pts, [(0, 0), (width, 0), (width, height), (0, height)])

        kwargs = {"fillcolor": self.fillcolor} if PILLOW_VERSION[0] == '5' else {}
        img2 = img1.transform((width, height), Image.PERSPECTIVE, coeffs, self.resample, **kwargs)

        # post transform on the image: normalized and converted to tensor
        if self.transform:
            img1 = self.transform(img1)
            img2 = self.transform(img2)

        coeffs = torch.from_numpy(np.array(coeffs, np.float32, copy=False)).view(8, 1, 1)

        # normalize transform parameters
        coeffs = self.matrix_transform(coeffs) if self.matrix_transform else coeffs

        return img1, img2, coeffs, self.labels[index]


class VideoTrainDataset(Dataset):
    def __init__(self, data_root, sample_interval=1, shift=6, scale=None, resample=False, fillcolor=0,
                 transform_pre=None, transform=None, matrix_transform=None):
        self.image_list = []

        self.shift = shift
        self.scale = scale
        self.resample = resample
        self.fillcolor = fillcolor
        self.transform_pre = transform_pre
        self.transform = transform
        self.matrix_transform = matrix_transform

        f_train_path = f'{data_root}/training/frames'
        print(f'Loading MVTechAD Training Images from {f_train_path} ...')
        for ffolderpath in glob.glob(f'{f_train_path}/*'):
            flist = sorted(glob.glob(f'{ffolderpath}/*.jpg'))
            self.image_list.extend(flist)

        if sample_interval != 1:
            self.image_list = [self.image_list[k] for k in range(0, len(self.image_list), sample_interval)]

    def __len__(self):
        return len(self.image_list)

    def __getitem__(self, index):
        img1 = Image.open(self.image_list[index]).convert('RGB')
        # preprocess transform on image1
        img1 = self.transform_pre(img1) if self.transform_pre else img1
        # projective transformation on image1 to get image2
        width, height = img1.size
        # calculate image center point
        center = (img1.size[0] * 0.5 + 0.5, img1.size[1] * 0.5 + 0.5)
        # sampling shifting coefficient
        shift = [float(random.randint(-int(self.shift), int(self.shift))) for _ in range(8)]
        # sampling scale ratio
        scale = random.uniform(self.scale[0], self.scale[1])
        # sampling rotation degree
        rotation = random.randint(0, 3)

        # projective transform
        pts = [((0 - center[0]) * scale + center[0], (0 - center[1]) * scale + center[1]),
               ((width - center[0]) * scale + center[0], (0 - center[1]) * scale + center[1]),
               ((width - center[0]) * scale + center[0], (height - center[1]) * scale + center[1]),
               ((0 - center[0]) * scale + center[0], (height - center[1]) * scale + center[1])]
        pts = [pts[(ii + rotation) % 4] for ii in range(4)]
        pts = [(pts[ii][0] + shift[2 * ii], pts[ii][1] + shift[2 * ii + 1]) for ii in range(4)]

        coeffs = find_coeffs(pts, [(0, 0), (width, 0), (width, height), (0, height)])

        kwargs = {"fillcolor": self.fillcolor} if PILLOW_VERSION[0] == '5' else {}
        img2 = img1.transform((width, height), Image.PERSPECTIVE, coeffs, self.resample, **kwargs)

        # post transform on the image: normalized and converted to tensor
        if self.transform:
            img1 = self.transform(img1)
            img2 = self.transform(img2)

        coeffs = torch.from_numpy(np.array(coeffs, np.float32, copy=False)).view(8, 1, 1)

        # normalize transform parameters
        coeffs = self.matrix_transform(coeffs) if self.matrix_transform else coeffs

        return img1, img2, coeffs


class VideoTestDataset(Dataset):
    def __init__(self, data_root, gnd_dir=None, shift=6, scale=None, resample=False, fillcolor=0,
                 transform_pre=None, transform=None, matrix_transform=None):
        self.image_list = []
        self.labels = []

        self.shift = shift
        self.scale = scale
        self.resample = resample
        self.fillcolor = fillcolor
        self.transform_pre = transform_pre
        self.transform = transform
        self.matrix_transform = matrix_transform

        f_test_path = f'{data_root}/testing/frames'
        print(f'Loading MVTechAD Testing Images from {f_test_path} ...')
        for ffolderpath in glob.glob(f'{f_test_path}/*'):
            self.image_list.extend(sorted(glob.glob(f'{ffolderpath}/*.jpg')))
        print('Loading Ground Truth ...')
        if 'avenue' in f_test_path:
            for lm_path in sorted(glob.glob(f'{gnd_dir}/*')):
                gnd = []
                mat = scio.loadmat(lm_path, squeeze_me=True)
                label_mask = mat['volLabel']
                for i in range(len(label_mask)):
                    cur_mask = label_mask[i]
                    gnd.append(1 if 1 in cur_mask else 0)
                self.labels.extend(gnd)
        elif 'ped' in f_test_path:
            fnum_list = []
            for fdir in glob.glob(f'{f_test_path}/*'):
                fnum_list.append(len(os.listdir(fdir)))
            gt_list = []
            gt_data = scio.loadmat(gnd_dir)['gt'][0]

            for gt_tuple in gt_data:
                gt_tuple = gt_tuple.squeeze()
                start, end = gt_tuple[0], gt_tuple[1]
                gt_list.append((start, end))

            y_trues = []
            for i in range(len(gt_list)):
                start, end = gt_list[i]
                fnum = fnum_list[i]
                y_true = np.zeros(shape=fnum).astype(np.uint8)
                if isinstance(start, np.ndarray) and isinstance(end, np.ndarray):
                    start1, end1 = start
                    start2, end2 = end
                    y_true[start1:end1] = 1
                    y_true[start2:end2] = 1
                else:
                    y_true[start:end] = 1
                y_true = y_true.tolist()
                y_trues.append(y_true)

        assert len(self.labels) == len(self.image_list)

    def __len__(self):
        return len(self.image_list)

    def __getitem__(self, index):
        img1 = Image.open(self.image_list[index]).convert('RGB')
        # preprocess transform on image1
        img1 = self.transform_pre(img1) if self.transform_pre else img1
        # projective transformation on image1 to get image2
        width, height = img1.size
        # calculate image center point
        center = (img1.size[0] * 0.5 + 0.5, img1.size[1] * 0.5 + 0.5)
        # sampling shifting coefficient
        shift = [float(random.randint(-int(self.shift), int(self.shift))) for _ in range(8)]
        # sampling scale ratio
        scale = random.uniform(self.scale[0], self.scale[1])
        # sampling rotation degree
        rotation = random.randint(0, 3)

        # projective transform
        pts = [((0 - center[0]) * scale + center[0], (0 - center[1]) * scale + center[1]),
               ((width - center[0]) * scale + center[0], (0 - center[1]) * scale + center[1]),
               ((width - center[0]) * scale + center[0], (height - center[1]) * scale + center[1]),
               ((0 - center[0]) * scale + center[0], (height - center[1]) * scale + center[1])]
        pts = [pts[(ii + rotation) % 4] for ii in range(4)]
        pts = [(pts[ii][0] + shift[2 * ii], pts[ii][1] + shift[2 * ii + 1]) for ii in range(4)]

        coeffs = find_coeffs(pts, [(0, 0), (width, 0), (width, height), (0, height)])

        kwargs = {"fillcolor": self.fillcolor} if PILLOW_VERSION[0] == '5' else {}
        img2 = img1.transform((width, height), Image.PERSPECTIVE, coeffs, self.resample, **kwargs)

        # post transform on the image: normalized and converted to tensor
        if self.transform:
            img1 = self.transform(img1)
            img2 = self.transform(img2)

        coeffs = torch.from_numpy(np.array(coeffs, np.float32, copy=False)).view(8, 1, 1)

        # normalize transform parameters
        coeffs = self.matrix_transform(coeffs) if self.matrix_transform else coeffs

        return img1, img2, coeffs, self.labels[index]


class MNISTDataset(VisionDataset):
    """`MNIST <http://yann.lecun.com/exdb/mnist/>`_ Dataset.

    Args:
        root (string): Root directory of dataset where ``MNIST/processed/training.pt``
            and  ``MNIST/processed/test.pt`` exist.
        train (bool, optional): If True, creates dataset from ``training.pt``,
            otherwise from ``test.pt``.
        download (bool, optional): If true, downloads the dataset from the internet and
            puts it in root directory. If dataset is already downloaded, it is not
            downloaded again.
        transform (callable, optional): A function/transform that  takes in an PIL image
            and returns a transformed version. E.g, ``transforms.RandomCrop``
        target_transform (callable, optional): A function/transform that takes in the
            target and transforms it.
    """

    resources = [
        ("http://yann.lecun.com/exdb/mnist/train-images-idx3-ubyte.gz", "f68b3c2dcbeaaa9fbdd348bbdeb94873"),
        ("http://yann.lecun.com/exdb/mnist/train-labels-idx1-ubyte.gz", "d53e105ee54ea40749a09fcbcd1e9432"),
        ("http://yann.lecun.com/exdb/mnist/t10k-images-idx3-ubyte.gz", "9fb629c4189551a2d022fa330f9573f3"),
        ("http://yann.lecun.com/exdb/mnist/t10k-labels-idx1-ubyte.gz", "ec29112dd5afa0611ce80d1b7f02629c")
    ]

    training_file = 'training.pt'
    test_file = 'test.pt'
    classes = ['0 - zero', '1 - one', '2 - two', '3 - three', '4 - four',
               '5 - five', '6 - six', '7 - seven', '8 - eight', '9 - nine']

    @property
    def train_labels(self):
        warnings.warn("train_labels has been renamed targets")
        return self.targets

    @property
    def test_labels(self):
        warnings.warn("test_labels has been renamed targets")
        return self.targets

    @property
    def train_data(self):
        warnings.warn("train_data has been renamed data")
        return self.data

    @property
    def test_data(self):
        warnings.warn("test_data has been renamed data")
        return self.data

    def __init__(self, root, shift=6, scale=None, resample=False, fillcolor=0, train=True,
                 transform_pre=None, transform=None, target_transform=None, matrix_transform=None,
                 download=True, number=0):
        super(MNISTDataset, self).__init__(root, transform=transform,
                                           target_transform=target_transform)
        self.train = train  # training set or test set

        if download:
            self.download()

        if not self._check_exists():
            raise RuntimeError('Dataset not found.' +
                               ' You can use download=True to download it')

        data_file = self.training_file if self.train else self.test_file
        self.data, self.targets = torch.load(os.path.join(self.processed_folder, data_file))
        self.data = self.data.unsqueeze(dim=-1)
        data_num, w, h, _ = self.data.size()
        self.data = self.data * torch.ones(data_num, w, h, 3, dtype=torch.uint8)
        self.data = self.data.numpy()
        if self.train:
            train_labels = np.array(self.targets)
            target_indices = np.squeeze(np.argwhere(train_labels == number))
            self.targets = self.targets[target_indices]
            self.data = self.data[target_indices]
        else:
            test_labels = np.array(self.targets)
            nor_indices = np.argwhere(test_labels == number)
            ano_indices = np.argwhere(test_labels != number)
            test_labels[ano_indices] = 1
            test_labels[nor_indices] = 0
            self.targets = test_labels

        self.shift, self.scale, self.resample, self.fillcolor = shift, scale, resample, fillcolor

        self.transform_pre, self.matrix_transform = transform_pre, matrix_transform

    def __getitem__(self, index):
        """
        Args:
            index (int): Index

        Returns:
            tuple: (image, target) where target is index of the target class.
        """
        img1, target = self.data[index], int(self.targets[index])

        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        img1 = Image.fromarray(img1)
        if self.transform_pre:
            img1 = self.transform_pre(img1)

        # projective transformation on image2
        img2, coeffs = projective_transform(img1, shift=self.shift, scale=self.scale, resample=self.resample,
                                            fillcolor=self.fillcolor)

        if self.transform:
            img1 = self.transform(img1)
            img2 = self.transform(img2)

        if self.target_transform:
            target = self.target_transform(target)

        coeffs = torch.from_numpy(np.array(coeffs, np.float32, copy=False)).view(8, 1, 1)

        if self.matrix_transform:
            coeffs = self.matrix_transform(coeffs)

        return img1, img2, coeffs, target

    def __len__(self):
        return len(self.data)

    @property
    def raw_folder(self):
        return os.path.join(self.root, self.__class__.__name__, 'raw')

    @property
    def processed_folder(self):
        return os.path.join(self.root, self.__class__.__name__, 'processed')

    @property
    def class_to_idx(self):
        return {_class: i for i, _class in enumerate(self.classes)}

    def _check_exists(self):
        return (os.path.exists(os.path.join(self.processed_folder,
                                            self.training_file)) and
                os.path.exists(os.path.join(self.processed_folder,
                                            self.test_file)))

    def download(self):
        """Download the MNIST data if it doesn't exist in processed_folder already."""

        if self._check_exists():
            return

        os.makedirs(self.raw_folder, exist_ok=True)
        os.makedirs(self.processed_folder, exist_ok=True)

        # download files
        for url, md5 in self.resources:
            filename = url.rpartition('/')[2]
            download_and_extract_archive(url, download_root=self.raw_folder, filename=filename, md5=md5)

        # process and save as torch files
        print('Processing...')

        training_set = (
            read_image_file(os.path.join(self.raw_folder, 'train-images-idx3-ubyte')),
            read_label_file(os.path.join(self.raw_folder, 'train-labels-idx1-ubyte'))
        )
        test_set = (
            read_image_file(os.path.join(self.raw_folder, 't10k-images-idx3-ubyte')),
            read_label_file(os.path.join(self.raw_folder, 't10k-labels-idx1-ubyte'))
        )
        with open(os.path.join(self.processed_folder, self.training_file), 'wb') as f:
            torch.save(training_set, f)
        with open(os.path.join(self.processed_folder, self.test_file), 'wb') as f:
            torch.save(test_set, f)

        print('Done!')

    def extra_repr(self):
        return "Split: {}".format("Train" if self.train is True else "Test")
