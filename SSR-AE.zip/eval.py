import argparse
import math
import os
import random

import PIL
import numpy as np
import torch
from sklearn.metrics import roc_curve, auc
from torch.backends import cudnn
from torch.utils.data import DataLoader
from torchvision import transforms

from dataset import MVTechTestDataset
from network import Regressor


def psnr_error(recon_images, gt_images):
    shape = recon_images.size()
    num_pixels = shape[1] * shape[2] * shape[3]
    square_diff = (recon_images - gt_images) ** 2
    batch_errors = 10 * torch.log10(1. / ((1. / num_pixels) * torch.mean(square_diff, [1, 2, 3])))
    return torch.tensor(batch_errors)


def min_max_normalize(arr):
    max_a = np.max(arr)
    min_a = np.min(arr)
    if min_a == max_a:
        return np.ones(shape=arr.shape)
    return (arr - min_a) / (max_a - min_a)


def chunk_tensor_for_error_list(err, alpha=0.5, beta=0.5):
    left, right = torch.chunk(err, chunks=2, dim=0)
    real_err = left * alpha + right * beta
    real_err = real_err.cpu().numpy().tolist()
    return real_err


def val(opt, net):
    print('Evaluating ... ')
    if isinstance(net, str):
        net = Regressor(_num_stages=4, _use_avg_on_conv3=False).cuda()
        net.load_state_dict(torch.load(f'{opt.net}'))
        net.eval()

    test_dataset = MVTechTestDataset(data_root=opt.dataroot, shift=opt.shift, scale=(opt.shrink, opt.enlarge),
                                     fillcolor=(128, 128, 128), resample=PIL.Image.BILINEAR,
                                     matrix_transform=transforms.Compose([
                                         transforms.Normalize((0., 0., 16., 0., 0., 16., 0., 0.),
                                                              (1., 1., 20., 1., 1., 20., 0.015, 0.015)),
                                     ]),
                                     transform_pre=transforms.Compose([
                                         transforms.Resize(opt.imageSize, interpolation=PIL.Image.BILINEAR),
                                         transforms.RandomCrop(opt.imageSize, padding=4),
                                         transforms.RandomHorizontalFlip(),
                                     ]),
                                     transform=transforms.Compose([
                                         transforms.ToTensor(),
                                         transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
                                     ]))


    recon_preds = []
    psnr_preds = []
    # prob_preds = []
    tf_preds = []
    y_trues = []
    total_img_num = test_dataset.__len__()
    test_batch_size = 32
    test_workers = 1
    test_batch_num = math.ceil(total_img_num / test_batch_size)
    test_dataloader = DataLoader(test_dataset, batch_size=test_batch_size, shuffle=False, num_workers=test_workers)

    norm_error, ano_error = [], []

    err_maps = []

    recon_imgs = []

    with torch.no_grad():
        for batch_index, data in enumerate(test_dataloader, 0):
            img1, img2, matrix, img_label = data[0], data[1], data[2], data[3]
            img1 = img1.cuda()
            img2 = img2.cuda()

            img = torch.cat([img1, img2])
            matrix = matrix.view(-1, 8).cuda()
            t_mu, t_log_var, img_mu, img_log_var, _ = net(img1, img2)

            ori_recon, tf_recon = torch.chunk(img_mu, chunks=2, dim=0)
            recon_imgs.append(ori_recon.cpu())
            # img_std = torch.exp(0.5 * img_log_var)

            square_diff = (img - img_mu) ** 2
            ori_diff, tf_diff = torch.chunk(square_diff, chunks=2, dim=0)
            err_maps.append(ori_diff.cpu())

            img_r_err = torch.mean((img - img_mu) ** 2, dim=[1, 2, 3])
            psnr = psnr_error(img_mu, img)
            tf_err = torch.mean((matrix - t_mu) ** 2, dim=1).cpu().numpy().tolist()
            # img_prob = torch.mean(torch.exp(-1 * (img - img_mu) ** 2 / img_std ** 2) / img_std)
            img_r_err = chunk_tensor_for_error_list(img_r_err, alpha=.5, beta=.5)
            psnr = chunk_tensor_for_error_list(psnr, alpha=.5, beta=.5)

            norm_indices = torch.where(img_label == 0)[0].cpu().numpy()
            ano_indices = torch.where(img_label == 1)[0].cpu().numpy()
            norm_error.extend(np.array(img_r_err)[norm_indices].tolist())
            ano_error.extend(np.array(img_r_err)[ano_indices].tolist())

            recon_preds.extend(img_r_err)
            psnr_preds.extend(psnr)
            # prob_preds.append(float(img_prob))
            tf_preds.extend(tf_err)

            y_trues.extend(img_label.cpu().numpy().tolist())
            print(f'\r Predicting Image Batch {batch_index + 1}/{test_batch_num} ...', end='')

    # Post process on the scores
    recon_preds = min_max_normalize(np.array(recon_preds))
    psnr_preds = min_max_normalize(np.array(psnr_preds))
    # prob_preds = min_max_normalize(np.array(prob_preds))
    tf_preds = min_max_normalize(np.array(tf_preds))

    psnr_tf_preds = min_max_normalize(psnr_preds - tf_preds * 0.1)
    recon_tf_preds = min_max_normalize(recon_preds + tf_preds * 0.1)

    fpr, tpr, th = roc_curve(y_trues, recon_preds, pos_label=1)
    recon_auc = auc(fpr, tpr)
    fpr, tpr, th = roc_curve(y_trues, psnr_preds, pos_label=0)
    psnr_auc = auc(fpr, tpr)
    fpr, tpr, th = roc_curve(y_trues, tf_preds, pos_label=1)
    tf_auc = auc(fpr, tpr)

    fpr, tpr, th = roc_curve(y_trues, psnr_tf_preds, pos_label=0)
    pnsr_tf_auc = auc(fpr, tpr)
    fpr, tpr, th = roc_curve(y_trues, recon_tf_preds, pos_label=1)
    recon_tf_auc = auc(fpr, tpr)

    return max([recon_auc, psnr_auc, tf_auc, pnsr_tf_auc, recon_tf_auc]) * 100


if __name__ == '__main__':
    # target_class = 'zipper'
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataroot', default=None, help='path to dataset')
    # Testing Setting
    parser.add_argument('--imageSize', type=int, default=256, help='the height / width of the input image to network')
    parser.add_argument('--gpu', type=int, default=0, help='gpu to use')
    parser.add_argument('--manualSeed', type=int, default=0, help='random seed')
    parser.add_argument('--val_iter', type=int, default=0, help='number of iterations for testing')
    parser.add_argument('--val_class', type=str, default='', help='testing class')
    # Model Setting
    parser.add_argument('--net', default='', help="path to net (to continue training)")
    # Image Transform Setting
    parser.add_argument('--shift', type=float, default=4.)  # 4
    parser.add_argument('--shrink', type=float, default=0.8)  # 0.8
    parser.add_argument('--enlarge', type=float, default=1.2)  # 1.2
    parser.add_argument('--divide', type=float, default=1000.)  # 1000
    parser.add_argument('--score_tf_ratio', default=1.0, type=float,
                        help='ratio of tf loss in the final calculation of joint anomaly scores')

    opt = parser.parse_args()

    os.environ['CUDA_VISIBLE_DEVICES'] = str(opt.gpu)

    if opt.manualSeed is None:
        opt.manualSeed = random.randint(1, 10000)
    print("Random Seed: ", opt.manualSeed)
    random.seed(opt.manualSeed)
    torch.manual_seed(opt.manualSeed)
    np.random.seed(opt.manualSeed)

    cudnn.benchmark = True
    torch.backends.cudnn.deterministic = True

    max_auc = 0.0
    print('-' * 50)
    # opt.net = f'weights/{target_class}.pth'
    best_auc = val(opt, net=opt.net)
    print(best_auc)
