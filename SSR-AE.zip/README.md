
# SSR-AE Official Pytorch Implementation

## Requirement

- Pytorch
- PIL
- argparse
- cv2
- numpy

## Usage

### Training

Example of training with MVTechAD on class *botlle*:

```shell
python train.py --dataroot [YourMVTechPath]/bottle --batchSize 4 --imageSize 256 --outf [YourPathToSaveOutputWeights] 
```

### Testing

Example of testing with MVTechAD on class *bottle*:

```shell
python eval.py --dataroot [YourMVTechPath]/bottle --net [YourModelWeightsDir]
```
