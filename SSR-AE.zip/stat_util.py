import glob
import os

import cv2
import torch
from tqdm import tqdm
import numpy as np


def get_recon_mask(matrix, index, save_dir):
    cmap_list = []
    for ichannal in range(matrix.size(0)):
        cmap = matrix[ichannal]
        max_pixel, min_pixel = torch.max(cmap), torch.min(cmap)
        cmap = (cmap - min_pixel) / (max_pixel - min_pixel) if max_pixel != min_pixel else torch.zeros(size=cmap.size())
        cmap_list.append(cmap)
    converted_map = torch.stack(cmap_list).permute(1, 2, 0).cpu().numpy() * 255
    cv2.imwrite(f'{save_dir}/{index}.jpg', converted_map)
    # cv2.imshow('', converted_map)
    # cv2.waitKey(0)


def rearrange_test_folder(data_dir, test_set_dir):
    print(f'Loading MVTechAD Testing Images from {data_dir}/test ...')
    for classname in tqdm(os.listdir(data_dir)):
        test_dir = os.path.join(data_dir, classname, 'test')
        save_dir = os.path.join(test_set_dir, classname)
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        class_obj_list = []
        for test_type in os.listdir(test_dir):
            type_object_list = sorted(glob.glob(f'{os.path.join(test_dir, test_type)}\\*.png'))
            class_obj_list.extend(type_object_list)
        for i in range(len(class_obj_list)):
            src_dir = class_obj_list[i]
            dst_dir = os.path.join(save_dir, f'{i}.jpg')
            os.system(f'copy {src_dir} {dst_dir}')


def gen_mask_folder(data_dir, mask_dir):
    for classname in tqdm(os.listdir(data_dir)):
        test_dir = os.path.join(data_dir, classname, 'test')
        mask_class_dir = os.path.join(mask_dir, classname)
        if not os.path.exists(mask_class_dir):
            os.makedirs(mask_class_dir)
        for test_type in os.listdir(test_dir):
            mask_type_dir = os.path.join(mask_class_dir, test_type)
            if not os.path.exists(mask_type_dir):
                os.makedirs(mask_type_dir)


def get_recon_img(matrix, index, save_dir):
    means, stds = (0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)
    recon_list = []
    for ichannal in range(matrix.size(0)):
        cmap = matrix[ichannal] * stds[ichannal] + means[ichannal]
        max_pixel, min_pixel = torch.max(cmap), torch.min(cmap)
        cmap = (cmap - min_pixel) / (max_pixel - min_pixel) if max_pixel != min_pixel else torch.zeros(size=cmap.size())
        recon_list.append(cmap)
    converted_map = torch.stack(recon_list).permute(1, 2, 0).cpu().numpy() * 255
    converted_map = cv2.cvtColor(converted_map, cv2.COLOR_RGB2BGR)
    cv2.imwrite(f'{save_dir}/{index}.jpg', converted_map)
    # cv2.imshow('', converted_map)
    # cv2.waitKey(0)


if __name__ == '__main__':
    # mask_dir = r'E:\PycharmProjects\SSR_AE\mask\bottle\58.jpg'
    # img_dir = r'F:\dataset\MVTecAD\test_set\bottle\58.jpg'
    # mask = cv2.imread(mask_dir)
    # mask = np.mean(mask, axis=-1)[:, :, np.newaxis]
    # mask = mask * np.ones(shape=(256, 256, 3), dtype=np.float)
    # img = cv2.resize(cv2.imread(img_dir), dsize=(256, 256))
    # masked_img = cv2.add(img, mask)
    # max_pixel, min_pixel = torch.max(masked_img), torch.min(masked_img)
    # masked_img = (masked_img - min_pixel) / (max_pixel - min_pixel) if max_pixel != min_pixel else torch.zeros(
    #     size=masked_img.size()).numpy()
    # cv2.imshow('', masked_img)
    # cv2.waitKey(0)
    # test_set_dir = r'F:\dataset\MVTecAD\test_set'
    # gen_mask_folder(data_dir=r'F:\dataset\MVTecAD\data', mask_dir=r'C:\Users\HIT\Desktop\image_mask')
    # rearrange_test_folder(data_dir=r'F:\dataset\MVTecAD\data', test_set_dir=test_set_dir)
    # save_dir = 'mask/bottle'
    # if not os.path.exists(save_dir):
    #     os.makedirs(save_dir)
    # diff_matrix = torch.load('square_diff_out/bottle.pt')
    # for i in tqdm(range(len(diff_matrix))):
    #     get_recon_mask(diff_matrix[i], i)
    # for diff in diff_matrix:
    #     print('')
    #     pass
    display_dir = 'display_img'
    recon_dir = 'recon_img'
    for classname in os.listdir(display_dir):
        save_dir = os.path.join(recon_dir, classname)
        class_dir = os.path.join(display_dir, classname)
        if not os.path.exists(save_dir):
            os.makedirs(save_dir)
        class_mat = torch.load(f'recon_out/{classname}.pt')
        for pic_id in sorted(os.listdir(class_dir)):
            pic_id = int(pic_id.split('.')[0])
            recon_mat = class_mat[pic_id]
            get_recon_img(recon_mat, pic_id, save_dir=save_dir)
