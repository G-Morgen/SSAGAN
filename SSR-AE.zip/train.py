from __future__ import print_function

import argparse
import os
import random
import time
from pathlib import Path

from torch.optim import Adam
from eval import val
import PIL
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.optim as optim
import torch.utils.data
import torchvision.transforms as transforms

from network import Regressor
from dataset import MVTechTrainDataset, VideoTrainDataset, CIFAR10, MNISTDataset


def update_optimizer(epoch):
    adjust_interval = [50, 600, 1800, 3000, 4500]
    if 50 <= epoch < 3240:
        optimizer.param_groups[0]['lr'] = config.lr * 5
        optimizer.param_groups[1]['lr'] = config.lr * config.lrMul
    elif 3240 <= epoch < 3480:
        optimizer.param_groups[0]['lr'] = config.lr * 5 * 0.2
        optimizer.param_groups[1]['lr'] = config.lr * config.lrMul
    elif 3480 <= epoch < 3640:
        optimizer.param_groups[0]['lr'] = config.lr * 5 * 0.04
        optimizer.param_groups[1]['lr'] = config.lr * config.lrMul * 0.001
    elif 3640 <= epoch < 3800:
        optimizer.param_groups[0]['lr'] = config.lr * 5 * 0.008
        optimizer.param_groups[1]['lr'] = config.lr * config.lrMul * 0.001
    elif 3800 <= epoch < 4000:
        optimizer.param_groups[0]['lr'] = config.lr * 5 * 0.0016
        optimizer.param_groups[1]['lr'] = config.lr * config.lrMul * 0.001
    elif epoch >= 4000:
        optimizer.param_groups[0]['lr'] = config.lr * 5 * 0.0016 - config.lr * 5 * 3e-6 * (epoch - 4000)
        optimizer.param_groups[1]['lr'] = config.lr * config.lrMul * 0.001

        # if adjust_interval[0] <= epoch < adjust_interval[1]:
        #     optimizer.param_groups[0]['lr'] = opt.lr * 5
        #     optimizer.param_groups[1]['lr'] = opt.lr * opt.lrMul
        # elif adjust_interval[1] <= epoch < adjust_interval[2]:
        #     optimizer.param_groups[0]['lr'] = opt.lr * 5 * 0.2
        #     optimizer.param_groups[1]['lr'] = opt.lr * opt.lrMul
        # elif adjust_interval[2] <= epoch < adjust_interval[3]:
        #     optimizer.param_groups[0]['lr'] = opt.lr * 5 * 0.04
        #     optimizer.param_groups[1]['lr'] = opt.lr * opt.lrMul * 0.001
        # elif adjust_interval[3] <= epoch < adjust_interval[4]:
        #     optimizer.param_groups[0]['lr'] = opt.lr * 5 * 0.008
        # optimizer.param_groups[1]['lr'] = opt.lr * opt.lrMul * 0.001
    # elif 3800 <= epoch < 4000:
    #     optimizer.param_groups[0]['lr'] = opt.lr * 5 * 0.0016
    #     optimizer.param_groups[1]['lr'] = opt.lr * opt.lrMul * 0.001
    # elif epoch >= 4000:
    #     optimizer.param_groups[0]['lr'] = opt.lr * 5 * 0.0016 - opt.lr * 5 * 3e-6 * (epoch - 4000)
    #     optimizer.param_groups[1]['lr'] = opt.lr * opt.lrMul * 0.001


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--dataroot', default=r'F:\MVTec\MvTecAD\bottle',
                        help='path to dataset')  # F:\dataset\MVTecAD\data\grid
    parser.add_argument('--gnd_dir', default=r'F:\dataset\avenue\ground_truth_demo\testing_label_mask',
                        help='path to labels')
    parser.add_argument('--sample_interval', type=int, default=30, help='sampling rate, used only on video dataset')
    parser.add_argument('--cifar_class', type=int, default=0, help='target class of cifar10 dataset: 0-9')
    parser.add_argument('--mnist_number', type=int, default=9, help='target number of mnist dataset: 0-9')
    # Training Setting
    parser.add_argument('--workers', type=int, help='number of data loading workers', default=4)
    parser.add_argument('--batchSize', type=int, default=4, help='input batch size')
    parser.add_argument('--imageSize', type=int, default=256, help='the height / width of the input image to network')
    parser.add_argument('--niter', type=int, default=1000, help='number of epochs to train for')
    parser.add_argument('--val_interval', type=int, default=10, help='evaluate every [val_interval] epochs')
    parser.add_argument('--save_interval', type=int, default=10, help='save model every [save_interval] epochs')
    parser.add_argument('--timecheck_interval', type=int, default=100, help='check current time')
    parser.add_argument('--gpu', type=int, default=0, help='gpu to use')
    # Model Setting
    parser.add_argument('--net', default=None, help="path to net (to continue training)")
    parser.add_argument('--outf', default=None,
                        help='folder to output images and model checkpoints')
    parser.add_argument('--tf_ratio', default=0.1, type=float, help='ratio of tf loss in training')
    parser.add_argument('--score_tf_ratio', default=1.0, type=float,
                        help='ratio of tf loss in the final calculation of joint anomaly scores')
    # Optimizer Setting
    parser.add_argument('--lr', type=float, default=1e-2, help='learning rate, default=0.0002')
    parser.add_argument('--lr_decay_factor', type=float, default=0.1,
                        help='multiply lr with [lr_decay_factor] on adjustment')
    parser.add_argument('--beta', type=float, default=0.5, help='beta1 for adam. default=0.5')
    parser.add_argument('--optimizer', default=None,
                        help="path to optimizer (to continue training)")
    parser.add_argument('--manualSeed', type=int, default=0, help='manual seed')
    parser.add_argument('--patience', type=int, default=10, help='[patience] epochs for reducing learning rate')
    parser.add_argument('--lrMul', type=float, default=10.)
    # Image Transform Setting
    parser.add_argument('--shift', type=float, default=4.)  # 4.
    parser.add_argument('--shrink', type=float, default=0.8)  # 0.8
    parser.add_argument('--enlarge', type=float, default=1.2)  # 1.2
    parser.add_argument('--divide', type=float, default=1000.)

    config = parser.parse_args()

    os.environ['CUDA_VISIBLE_DEVICES'] = str(config.gpu)

    Path(config.outf).mkdir(parents=True, exist_ok=True)

    if config.manualSeed is None:
        config.manualSeed = random.randint(1, 10000)
    print("Random Seed: ", config.manualSeed)
    random.seed(config.manualSeed)
    torch.manual_seed(config.manualSeed)

    cudnn.benchmark = True

    train_dataset = MVTechTrainDataset(data_root=config.dataroot,
                                       shift=config.shift,
                                       scale=(config.shrink, config.enlarge),
                                       fillcolor=(128, 128, 128),
                                       resample=PIL.Image.BILINEAR,
                                       matrix_transform=transforms.Compose([
                                           transforms.Normalize((0., 0., 16., 0., 0., 16., 0., 0.),
                                                                (1., 1., 20., 1., 1., 20., 0.015, 0.015)),
                                       ]),
                                       transform_pre=transforms.Compose([
                                           transforms.Resize(config.imageSize),
                                           transforms.RandomCrop(config.imageSize, padding=4),
                                           transforms.RandomHorizontalFlip(),
                                       ]),
                                       transform=transforms.Compose([
                                           transforms.ToTensor(),
                                           transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010)),
                                       ]),
                                       data_mode='part'
                                       )


    train_dataloader = torch.utils.data.DataLoader(train_dataset, batch_size=config.batchSize,
                                                   shuffle=True, num_workers=int(config.workers), pin_memory=True)

    net = Regressor(_num_stages=4, _use_avg_on_conv3=False, in_channels=3).cuda()

    if config.net:
        net.load_state_dict(torch.load(config.net))

    # print(net)

    criterion = nn.MSELoss()

    # setup optimizer
    # fc2_params = list(map(id, net.fc2.parameters()))
    # base_params = filter(lambda p: id(p) not in fc2_params, net.parameters())
    #
    # optimizer = optim.SGD([{'params': base_params}, {'params': net.fc2.parameters(), 'lr': opt.lr * opt.lrMul}],
    #                       lr=opt.lr, momentum=0.9, weight_decay=5e-4, nesterov=True)

    optimizer = Adam(net.parameters(), lr=config.lr, weight_decay=5e-4)

    # scheduler = optim.lr_scheduler.CosineAnnealingWarmRestarts(optimizer, T_0=60, T_mult=2, eta_min=1e-6)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=config.lr_decay_factor,
                                                     patience=config.patience,
                                                     verbose=True,
                                                     threshold=1e-4)

    if config.optimizer:
        optimizer.load_state_dict(torch.load(config.optimizer))

    for epoch in range(1, config.niter + 1):
        # update_optimizer(epoch)
        epoch_loss = {
            'img_loss': 0.0,
            'img_opt_loss': 0.0,
            't_loss': 0.0,
            "t_opt_loss": 0.0,
            'total_loss': 0.0
        }
        for i, data in enumerate(train_dataloader, 0):
            net.zero_grad()
            img1 = data[0].cuda()
            img2 = data[1].cuda()
            batch_size = img1.size(0)
            img = torch.cat([img1, img2])

            t_gnd = data[2].cuda()
            t_gnd = t_gnd.view(-1, 8)

            t_mu, t_log_var, img_mu, img_log_var, _ = net(img1, img2)

            # Reconstruction Error
            img_err = criterion(img_mu, img)

            # Mutual Information on Image
            img_log_var = img_log_var / config.divide
            img_std_sqr = torch.exp(img_log_var)
            # img_mi_err = (torch.sum(img_log_var) + torch.sum((img - img_mu) ** 2 / (img_std_sqr + 1e-4))) / batch_size
            img_mi_err = torch.mean(img_log_var + (img - img_mu) ** 2 / (img_std_sqr + 1e-4))

            # Transform Approximation Loss
            t_err = criterion(t_mu, t_gnd)
            t_log_var = t_log_var / config.divide
            t_std_sqr = torch.exp(t_log_var)
            # t_mi_err = (torch.sum(t_log_var) + torch.sum((t_mu - t_gnd) ** 2 / (t_std_sqr + 1e-4))) / batch_size
            t_mi_err = torch.mean(t_log_var + (t_gnd - t_mu) ** 2 / (t_std_sqr + 1e-4)) * config.tf_ratio

            # Merge loss
            total_loss = img_mi_err + t_mi_err

            epoch_loss['img_loss'] += float(img_err)
            epoch_loss['img_opt_loss'] += float(img_mi_err)
            epoch_loss['t_loss'] += float(t_err)
            epoch_loss['t_opt_loss'] += float(t_mi_err)
            epoch_loss['total_loss'] += float(total_loss)

            total_loss.backward()
            optimizer.step()

        print(f'[{epoch}/{config.niter}]'
              f'\t img_loss:{epoch_loss["img_loss"]:.4f}'
              f'\t img_opt_loss:{epoch_loss["img_opt_loss"]:.4f}'
              f'\t t_loss:{epoch_loss["t_loss"]:.4f}'
              f'\t t_opt_loss:{epoch_loss["t_opt_loss"]:.4f}'
              )
        scheduler.step(epoch_loss['total_loss'])
        # do checkpointing
        if not epoch % config.save_interval:
            torch.save(net.state_dict(), '%s/net_epoch_%d.pth' % (config.outf, epoch))
            torch.save(optimizer.state_dict(), '%s/optimizer_epoch_%d.pth' % (config.outf, epoch))

        if not epoch % config.val_interval:
            net.eval()
            val(opt=config, net=net)
            net.train()
